#ifndef slic3r_GUI_hpp_
#define slic3r_GUI_hpp_

namespace Slic3r { namespace GUI {

void disable_screensaver();
void enable_screensaver();

} }

#endif
